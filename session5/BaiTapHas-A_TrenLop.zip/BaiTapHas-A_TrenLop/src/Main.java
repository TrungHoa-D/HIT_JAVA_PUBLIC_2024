public class Main {
    public static void main(String[] args) {
        Hang hang = new Hang();
        hang.nhap();
        hang.xuat();
    }
}